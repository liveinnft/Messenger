#include "server.h"
#include "protocol.h"
#include <iostream>
#include <thread>

Server::Server(int port, Database* database)
    : serverSocket(INVALID_SOCKET), port(port), db(database), running(false) {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
}

Server::~Server() {
    stop();
    WSACleanup();
}

bool Server::start() {
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Failed to create socket" << std::endl;
        return false;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(port);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed" << std::endl;
        return false;
    }

    if (listen(serverSocket, 10) == SOCKET_ERROR) {
        std::cerr << "Listen failed" << std::endl;
        return false;
    }

    running = true;
    std::cout << "Server started on port " << port << std::endl;
    return true;
}

void Server::stop() {
    running = false;
    if (serverSocket != INVALID_SOCKET) {
        closesocket(serverSocket);
    }
}

void Server::run() {
    while (running) {
        sockaddr_in clientAddr;
        int clientLen = sizeof(clientAddr);
        SOCKET clientSocket = accept(serverSocket, (sockaddr*)&clientAddr, &clientLen);

        if (clientSocket == INVALID_SOCKET) {
            if (running) {
                std::cerr << "Accept failed" << std::endl;
            }
            continue;
        }

        std::cout << "New client connected: " << clientSocket << std::endl;
        std::thread(&Server::handleClient, this, clientSocket).detach();
    }
}

void Server::handleClient(SOCKET clientSocket) {
    char buffer[4096];

    while (running) {
        memset(buffer, 0, sizeof(buffer));
        int bytesRead = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);

        if (bytesRead <= 0) {
            break;
        }

        std::string message(buffer);
        processMessage(clientSocket, message);
    }

    for (auto it = clients.begin(); it != clients.end(); ++it) {
        if (it->first == clientSocket) {
            std::cout << "Client disconnected: " << it->second << std::endl;
            clients.erase(it);
            break;
        }
    }

    closesocket(clientSocket);
}

void Server::processMessage(SOCKET clientSocket, const std::string& message) {
    auto parts = Protocol::split(message, Protocol::DELIMITER);
    if (parts.empty()) return;

    Protocol::MessageType type = Protocol::stringToType(parts[0]);

    switch (type) {
    case Protocol::REGISTER: {
        if (parts.size() >= 3) {
            bool success = db->registerUser(parts[1], parts[2]);
            std::string response = success ?
                Protocol::createMessage(Protocol::RESPONSE_OK, {}) :
                Protocol::createMessage(Protocol::RESPONSE_ERROR, { "Registration failed" });
            send(clientSocket, response.c_str(), (int)response.length(), 0);
        }
        break;
    }

    case Protocol::LOGIN: {
        if (parts.size() >= 3) {
            bool success = db->loginUser(parts[1], parts[2]);
            if (success) {
                clients[clientSocket] = parts[1];
                std::string response = Protocol::createMessage(Protocol::RESPONSE_OK, {});
                send(clientSocket, response.c_str(), (int)response.length(), 0);
            }
            else {
                std::string response = Protocol::createMessage(Protocol::RESPONSE_ERROR, { "Login failed" });
                send(clientSocket, response.c_str(), (int)response.length(), 0);
            }
        }
        break;
    }

    case Protocol::GET_USERS: {
        auto users = db->getUsers();
        std::string response = Protocol::createMessage(Protocol::USER_LIST, users);
        send(clientSocket, response.c_str(), (int)response.length(), 0);
        break;
    }

    case Protocol::GET_MESSAGES: {
        if (parts.size() >= 3) {
            auto messages = db->getMessages(parts[1], parts[2]);
            std::vector<std::string> msgData;
            for (const auto& msg : messages) {
                msgData.push_back(msg.sender);
                msgData.push_back(msg.receiver);
                msgData.push_back(msg.message);
                msgData.push_back(msg.timestamp);
            }
            std::string response = Protocol::createMessage(Protocol::MESSAGE_LIST, msgData);
            send(clientSocket, response.c_str(), (int)response.length(), 0);
        }
        break;
    }

    case Protocol::MSG: {
        if (parts.size() >= 4) {
            db->saveMessage(parts[1], parts[2], parts[3]);
            std::string response = Protocol::createMessage(Protocol::RESPONSE_OK, {});
            send(clientSocket, response.c_str(), (int)response.length(), 0);

            std::string notification = Protocol::createMessage(Protocol::NEW_MESSAGE,
                { parts[1], parts[2], parts[3] });
            broadcastToUser(parts[2], notification);
        }
        break;
    }

    default:
        break;
    }
}

void Server::broadcastToUser(const std::string& username, const std::string& message) {
    for (const auto& client : clients) {
        if (client.second == username) {
            send(client.first, message.c_str(), (int)message.length(), 0);
            break;
        }
    }
}