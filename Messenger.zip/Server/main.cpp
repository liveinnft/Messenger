#include "server.h"
#include "database.h"
#include <iostream>

int main() {
    int port = 8888;

    Database db;
    if (!db.init()) {
        std::cerr << "Failed to initialize database" << std::endl;
        return 1;
    }

    Server server(port, &db);

    if (!server.start()) {
        std::cerr << "Failed to start server" << std::endl;
        return 1;
    }

    std::cout << "Press Ctrl+C to stop server..." << std::endl;
    server.run();

    return 0;
}