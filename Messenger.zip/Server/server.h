#ifndef SERVER_H
#define SERVER_H

#include <string>
#include <map>
#include <vector>
#include <winsock2.h>
#include <ws2tcpip.h>
#include "database.h"

#pragma comment(lib, "ws2_32.lib")

class Server {
private:
    SOCKET serverSocket;
    int port;
    Database* db;
    std::map<SOCKET, std::string> clients;
    bool running;

    void handleClient(SOCKET clientSocket);
    void processMessage(SOCKET clientSocket, const std::string& message);
    void broadcastToUser(const std::string& username, const std::string& message);

public:
    Server(int port, Database* database);
    ~Server();

    bool start();
    void stop();
    void run();
};

#endif